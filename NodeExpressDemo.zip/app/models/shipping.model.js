const mongoose = require('mongoose');

const ShippingSchema = mongoose.Schema({
    type: String,
    price: String
}, {
    timestamps: true
});

module.exports = mongoose.model('Shipping', ShippingSchema);
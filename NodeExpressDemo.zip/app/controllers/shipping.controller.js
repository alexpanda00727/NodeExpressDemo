const Shipping = require('../models/shipping.model.js');

// Create and Save a new Shipping
exports.create = (req, res) => {
    // Validate request
    if(!req.body.price) {
        return res.status(400).send({
            message: "Shipping price can not be empty"
        });
    }

    // Create a Shipping
    const shipping = new Shipping({
        type: req.body.type || "Untyped Shipping", 
        price: req.body.price
    });

    // Save Shipping in the database
    shipping.save()
    .then(data => {
        res.send(data);
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Some error occurred while creating the Shipping."
        });
    });
};


// Retrieve and return all shippings from the database.
exports.findAll = (req, res) => {
    Shipping.find()
    .then(shippings => {
        res.send(shippings);
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Some error occurred while retrieving shippings."
        });
    });
};


// Find a single shipping with a shippingId
exports.findOne = (req, res) => {
    Shipping.findById(req.params.shippingId)
    .then(shipping => {
        if(!shipping) {
            return res.status(404).send({
                message: "Shipping not found with id " + req.params.shippingId
            });            
        }
        res.send(shipping);
    }).catch(err => {
        if(err.kind === 'ObjectId') {
            return res.status(404).send({
                message: "Shipping not found with id " + req.params.shippingId
            });                
        }
        return res.status(500).send({
            message: "Error retrieving shipping with id " + req.params.shippingId
        });
    });
};


// Update a shipping identified by the shippingId in the request
exports.update = (req, res) => {
    // Validate Request
    if(!req.body.price) {
        return res.status(400).send({
            message: "Shipping price can not be empty"
        });
    }

    // Find shipping and update it with the request body
    Shipping.findByIdAndUpdate(req.params.shippingId, {
        type: req.body.type || "Untyped Shipping",
        price: req.body.price
    }, {new: true})
    .then(shipping => {
        if(!shipping) {
            return res.status(404).send({
                message: "Shipping not found with id " + req.params.shippingId
            });
        }
        res.send(shipping);
    }).catch(err => {
        if(err.kind === 'ObjectId') {
            return res.status(404).send({
                message: "Shipping not found with id " + req.params.shippingId
            });                
        }
        return res.status(500).send({
            message: "Error updating shipping with id " + req.params.shippingId
        });
    });
};

// Delete a shipping with the specified shippingId in the request
exports.delete = (req, res) => {
    Shipping.findByIdAndRemove(req.params.shippingId)
    .then(shipping => {
        if(!shipping) {
            return res.status(404).send({
                message: "Shipping not found with id " + req.params.shippingId
            });
        }
        res.send({message: "Shipping deleted successfully!"});
    }).catch(err => {
        if(err.kind === 'ObjectId' || err.name === 'NotFound') {
            return res.status(404).send({
                message: "Shipping not found with id " + req.params.shippingId
            });                
        }
        return res.status(500).send({
            message: "Could not delete shipping with id " + req.params.shippingId
        });
    });
};
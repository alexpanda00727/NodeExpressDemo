module.exports = (app) => {
    const shipping = require('../controllers/shipping.controller.js');

    // Create a new shipping
    app.post('/shipping', shipping.create);

    // Retrieve all shipping
    app.get('/shipping', shipping.findAll);

    // Retrieve a single shipping with shippingId
    app.get('/shipping/:shippingId', shipping.findOne);

    // Update a shipping with shippingId
    app.put('/shipping/:shippingId', shipping.update);

    // Delete a shipping with shippingId
    app.delete('/shipping/:shippingId', shipping.delete);
}